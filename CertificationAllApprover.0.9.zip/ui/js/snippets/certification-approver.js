/**
 */

function askUserIfBulkApprove(){
	var bulkApproveChoice = confirm("Would you like to bulk approve on displayed items ?");
	   if ( bulkApproveChoice ){
		   jQuery(".cert-action-Approved").click();
	   }
}
function removeBulkApproveAllOption(){
	jQuery( "#uiCertificationItemWorksheetColumns-Open > sp-data-table > div.data-table-container.ng-isolate-scope > div > div > div > div.panel-body.table-fixed-right > div > table > thead > tr > th.checkbox-col.ng-scope > span > ul > li:nth-child(2) > a").remove()

}
jQuery(window).ready(function(){
	
//	jQuery(".navbar-left")
//	    .append(
//	    		'<li role="presentation">'+
//	    		'	<a href="javascript:askUserIfBulkApprove();" role="menuitem" class="menuitem" tabindex="0">'+
//	    		'			My certifications actions'+
//	    		'	 </a>'+
//	    		'</li>'        		
//	    );
	setInterval(function(){ removeBulkApproveAllOption()}, 1000);
	
});