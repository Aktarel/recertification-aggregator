
/**
 * Create the module.
 */
var todoModule = angular.module('CustomCertificationModule', ['ui.bootstrap']);

/**
 * Controller for the todo list.
 */
todoModule.controller('CertController', function(todoService, pageConfigService, $q, $uibModal) {

    var me = this,
        promises;

    /**
     * @property Object The page config.
     */
    me.pageConfig = {};


    /**
     * Fetches the page config from the server.
     *
     * @return Promise A promise that resolves with the page config object.
     */
    function fetchPageConfig() {
        return pageConfigService.getPageConfig();
    }

    promises = {
        pageConfig: fetchPageConfig()
    };

    // load the page config and the todos
    $q.all(promises).then(function(result) {
        me.pageConfig = result.pageConfig;
        console.log(result);
    });

});
